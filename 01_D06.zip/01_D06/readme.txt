CÁCH CHẠY CODE
Bước 1: Tải XAMPP

Bước 2: Mở Xampp
Trong Xampp bật Start với Apache và MySQL

Tiếp theo bấm vào phần Xampphtdocs tạo folder với tên là nhóm và model, tạo file để chứa code vào
MỞ VS Studio chọn folder bài tập mà mình cần sau đó gắn code vào file đã tạo sẵn
Truy cập vào http://localhost/phpmyadmin để tạo bảng
Chọn New để tạo bảng đặt tên cho bảng:"quanlydonhang_new1";
Trên thanh công cụ chọn ô SQL
Tạo bảng trong phần này
Xong rồi ấn GO
Bước 3 : Mở code ra và chạy Php server
truy cập giao hàng nhanh:https://khachhang.ghn.vn/order/order-created để kiểm tra đơn hàng thật
tài khoản:0332133252
Mật khẩu:Xuantuan01@
tạo đơn hàng được 3 đơn do chính sách của giao hàng nhanh.
Khi đơn được tạo từ chương trình sẽ được cập nhật lên trang web của giao hàng nhanh, các trạng thái sẽ được cập theo trạng thái đơn thật khi được bên giao hàng nhanh thao tác và giao hàng.






