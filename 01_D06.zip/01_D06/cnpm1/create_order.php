<?php
// create_order.php
require 'config.php';
require 'ghn_api.php';

// ===============================
// Danh sách quận/huyện ĐÀ NẴNG
// ===============================
$daNangDistricts = [
    3440 => 'Quận Cẩm Lệ',
    3442 => 'Quận Hải Châu',
    3443 => 'Quận Thanh Khê',
    3444 => 'Quận Sơn Trà',
    3445 => 'Quận Ngũ Hành Sơn',
    3441 => 'Quận Liên Chiểu',
    3446 => 'Huyện Hòa Vang',
];

// ===============================
// Danh sách PHƯỜNG/XÃ theo quận
// ===============================
$wardsByDistrict = [
    3440 => [
        ['code' => '20308', 'name' => 'Phường Hòa An'],
        ['code' => '20309', 'name' => 'Phường Hòa Phát'],
        ['code' => '20310', 'name' => 'Phường Hòa Thọ Tây'],
        ['code' => '20311', 'name' => 'Phường Hòa Thọ Đông'],
        ['code' => '20312', 'name' => 'Phường Hòa Xuân'],
    ],
    3442 => [
        ['code' => '20113', 'name' => 'Phường Hải Châu I'],
        ['code' => '20114', 'name' => 'Phường Hải Châu II'],
        ['code' => '20115', 'name' => 'Phường Thạch Thang'],
        ['code' => '20116', 'name' => 'Phường Thanh Bình'],
        ['code' => '20117', 'name' => 'Phường Hòa Thuận Tây'],
        ['code' => '20118', 'name' => 'Phường Hòa Thuận Đông'],
        ['code' => '20119', 'name' => 'Phường Nam Dương'],
        ['code' => '20120', 'name' => 'Phường Bình Hiên'],
        ['code' => '20121', 'name' => 'Phường Bình Thuận'],
        ['code' => '20122', 'name' => 'Phường Phước Ninh'],
        ['code' => '20123', 'name' => 'Phường Hải Châu'],
        ['code' => '20124', 'name' => 'Phường Thuận Phước'],
    ],
    3443 => [
        ['code' => '20201', 'name' => 'Phường Thanh Khê Tây'],
        ['code' => '20202', 'name' => 'Phường Thanh Khê Đông'],
        ['code' => '20203', 'name' => 'Phường Xuân Hà'],
        ['code' => '20204', 'name' => 'Phường Tân Chính'],
        ['code' => '20205', 'name' => 'Phường Chính Gián'],
        ['code' => '20206', 'name' => 'Phường Thạc Gián'],
        ['code' => '20207', 'name' => 'Phường Vĩnh Trung'],
        ['code' => '20208', 'name' => 'Phường An Khê'],
        ['code' => '20209', 'name' => 'Phường Hòa Khê'],
    ],
    3444 => [
        ['code' => '20301', 'name' => 'Phường An Hải Bắc'],
        ['code' => '20302', 'name' => 'Phường An Hải Tây'],
        ['code' => '20303', 'name' => 'Phường An Hải Đông'],
        ['code' => '20304', 'name' => 'Phường Phước Mỹ'],
        ['code' => '20305', 'name' => 'Phường Mân Thái'],
        ['code' => '20306', 'name' => 'Phường Thọ Quang'],
        ['code' => '20307', 'name' => 'Phường Nại Hiên Đông'],
    ],
    3445 => [
        ['code' => '20401', 'name' => 'Phường Mỹ An'],
        ['code' => '20402', 'name' => 'Phường Khuê Mỹ'],
        ['code' => '20403', 'name' => 'Phường Hòa Quý'],
        ['code' => '20404', 'name' => 'Phường Hòa Hải'],
    ],
    3441 => [
        ['code' => '20501', 'name' => 'Phường Hòa Hiệp Bắc'],
        ['code' => '20502', 'name' => 'Phường Hòa Hiệp Nam'],
        ['code' => '20503', 'name' => 'Phường Hòa Minh'],
        ['code' => '20504', 'name' => 'Phường Hòa Khánh Bắc'],
        ['code' => '20505', 'name' => 'Phường Hòa Khánh Nam'],
    ],
    3446 => [
        ['code' => '20601', 'name' => 'Xã Hòa Bắc'],
        ['code' => '20602', 'name' => 'Xã Hòa Liên'],
        ['code' => '20603', 'name' => 'Xã Hòa Ninh'],
        ['code' => '20604', 'name' => 'Xã Hòa Sơn'],
        ['code' => '20605', 'name' => 'Xã Hòa Nhơn'],
        ['code' => '20606', 'name' => 'Xã Hòa Phú'],
        ['code' => '20607', 'name' => 'Xã Hòa Phong'],
        ['code' => '20608', 'name' => 'Xã Hòa Châu'],
        ['code' => '20609', 'name' => 'Xã Hòa Tiến'],
        ['code' => '20610', 'name' => 'Xã Hòa Phước'],
        ['code' => '20611', 'name' => 'Xã Hòa Khương'],
    ],
];

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerName  = trim($_POST['customer_name']  ?? '');
    $customerPhone = trim($_POST['customer_phone'] ?? '');
    $customerAddr  = trim($_POST['customer_addr']  ?? '');
    $districtIdRaw = $_POST['district_id']         ?? '';
    $districtId    = (int)$districtIdRaw;
    $wardCode      = $_POST['ward_code']          ?? '';

    // Validate
    if ($customerName === '' || $customerPhone === '' || $customerAddr === '' 
        || $districtIdRaw === '' || $wardCode === '') {
        $message = 'Vui lòng nhập đầy đủ thông tin.';
        $messageType = 'danger';
    } elseif (!array_key_exists($districtId, $daNangDistricts)) {
        $message = 'Sai quận/huyện.';
        $messageType = 'danger';
    } else {
        // Kiểm tra phường có thuộc quận không
        $validWard = false;
        if (isset($wardsByDistrict[$districtId])) {
            foreach ($wardsByDistrict[$districtId] as $w) {
                if ($w['code'] == $wardCode) {
                    $validWard = true;
                    break;
                }
            }
        }

        if (!$validWard) {
            $message = 'Phường không thuộc quận đã chọn.';
            $messageType = 'danger';
        } else {
            try {
                // =======================================
                // 1. GỌI GHN TÍNH PHÍ VẬN CHUYỂN
                // =======================================
                $feeData = [
                    "from_district_id" => $GHN_FROM_DISTRICT,
                    "from_ward_code"   => $GHN_FROM_WARD,
                    "to_district_id"   => $districtId,
                    "to_ward_code"     => $wardCode,
                    "service_type_id"  => 2,
                    "weight"           => 500,
                    "length"           => 20,
                    "width"            => 20,
                    "height"           => 10,
                    "cod_value"        => 0
                ];

                $feeRes = ghn_post('/v2/shipping-order/fee', $feeData);

                if (empty($feeRes['code']) || $feeRes['code'] != 200) {
                    throw new Exception("GHN fee error: " . json_encode($feeRes));
                }

                $shippingFee = (int)$feeRes['data']['total'];

                // =======================================
                // 2. LƯU ORDER + GỌI GHN TẠO ĐƠN THẬT
                // =======================================
                $pdo->beginTransaction();

                $orderId    = uniqid('O');
                $deliveryId = uniqid('D');

                // Lưu Orders
                $stmt = $pdo->prepare("
                    INSERT INTO Orders (ID, CustomerID, OrderDate, OrderStatus)
                    VALUES (?, ?, NOW(), 'Đang xử lý')
                ");
                $stmt->execute([$orderId, $customerName]);

                // Gọi GHN tạo đơn THẬT
                $ghnData = [
                    "shop_id"          => $GHN_SHOP_ID,
                    "from_name"        => $GHN_FROM_NAME,
                    "from_phone"       => $GHN_FROM_PHONE,
                    "from_address"     => $GHN_FROM_ADDRESS,
                    "from_ward_code"   => $GHN_FROM_WARD,
                    "from_district_id" => $GHN_FROM_DISTRICT,
                    "to_name"          => $customerName,
                    "to_phone"         => $customerPhone,
                    "to_address"       => $customerAddr,
                    "to_ward_code"     => $wardCode,
                    "to_district_id"   => $districtId,
                    "service_type_id"  => 2,
                    "payment_type_id"  => 1,
                    "cod_amount"       => 0,
                    "weight"           => 500,
                    "required_note"    => "KHONGCHOXEMHANG",
                    "items"            => [
                        [
                            "name"     => "Demo sản phẩm",
                            "quantity" => 1,
                            "price"    => 100000
                        ]
                    ]
                ];

                $res = ghn_post('/v2/shipping-order/create', $ghnData);

                if (empty($res['code']) || $res['code'] != 200) {
                    // GHN báo lỗi (kể cả vượt 3 đơn) => rollback & báo ra ngoài
                    throw new Exception("GHN create error: " . json_encode($res));
                }

                $trackingCode = $res['data']['order_code'];

                // Lưu DeliveryDetail
                $stmt = $pdo->prepare("
                    INSERT INTO DeliveryDetail (ID, OrderID, TrackingCode, UpdateDate, Status)
                    VALUES (?, ?, ?, NOW(), 'Đã tạo đơn')
                ");
                $stmt->execute([
                    $deliveryId,
                    $orderId,
                    $trackingCode
                ]);

                // Lưu Payment (có ShippingFee)
                $paymentId = uniqid('P');
                $stmt = $pdo->prepare("
                    INSERT INTO Payment (ID, OrderID, PaymentMethod, PaymentStatus, PaymentDate, ShippingFee)
                    VALUES (?, ?, 'COD', 'Chưa thanh toán', NULL, ?)
                ");
                $stmt->execute([
                    $paymentId,
                    $orderId,
                    $shippingFee
                ]);

                $pdo->commit();

                $feeText = number_format($shippingFee, 0, ',', '.');
                $message = "✔ Đặt hàng & tạo đơn GHN thành công!<br>
                            • Mã đơn nội bộ: <b>$orderId</b><br>
                            • Mã GHN: <b>$trackingCode</b><br>
                            • Phí vận chuyển: <b>{$feeText}đ</b>";
                $messageType = 'success';
                $_POST = [];

            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $message = "Lỗi: " . htmlspecialchars($e->getMessage());
                $messageType = 'danger';
            }
        }
    }
}

require 'header.php';
?>

<div class="row justify-content-center">
  <div class="col-md-8">
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <h3 class="mb-3">Tạo đơn hàng Đà Nẵng (GHN thật)</h3>

        <?php if ($message): ?>
          <div class="alert alert-<?= $messageType ?>"><?= $message ?></div>
        <?php endif; ?>

        <form method="post" class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Tên khách hàng</label>
            <input type="text" name="customer_name" class="form-control"
                   value="<?= htmlspecialchars($_POST['customer_name'] ?? '') ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label">Số điện thoại</label>
            <input type="text" name="customer_phone" class="form-control"
                   value="<?= htmlspecialchars($_POST['customer_phone'] ?? '') ?>">
          </div>

          <div class="col-12">
            <label class="form-label">Địa chỉ (số nhà + đường)</label>
            <input type="text" name="customer_addr" class="form-control"
                   value="<?= htmlspecialchars($_POST['customer_addr'] ?? '') ?>">
          </div>

          <div class="col-md-6">
            <label class="form-label">Quận/Huyện</label>
            <select name="district_id" id="districtSelect" class="form-select">
              <option value="">-- Chọn --</option>
              <?php foreach ($daNangDistricts as $id => $name): ?>
                <option value="<?= $id ?>"
                    <?= (isset($_POST['district_id']) && $_POST['district_id'] == $id) ? 'selected' : '' ?>>
                  <?= htmlspecialchars($name) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-md-6">
            <label class="form-label">Phường/Xã</label>
            <select name="ward_code" id="wardSelect" class="form-select">
              <option value="">-- Chọn --</option>
            </select>
          </div>

          <div class="col-12 text-end">
            <a href="index.php" class="btn btn-outline-secondary">⬅ Về trang chủ</a>
            <button class="btn btn-primary">🚚 Tạo đơn GHN</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
const wardsData = <?= json_encode($wardsByDistrict, JSON_UNESCAPED_UNICODE); ?>;
const districtSelect = document.getElementById('districtSelect');
const wardSelect = document.getElementById('wardSelect');
const selectedWard = "<?= htmlspecialchars($_POST['ward_code'] ?? '') ?>";

function loadWards() {
    wardSelect.innerHTML = '<option value="">-- Chọn --</option>';
    const d = districtSelect.value;
    if (wardsData[d]) {
        wardsData[d].forEach(w => {
            const opt = document.createElement('option');
            opt.value = w.code;
            opt.textContent = w.name;
            if (w.code === selectedWard) opt.selected = true;
            wardSelect.appendChild(opt);
        });
    }
}

districtSelect.addEventListener('change', loadWards);
document.addEventListener('DOMContentLoaded', loadWards);
</script>

<?php require 'footer.php'; ?>
