<?php
// config.php

// ==============================
// KẾT NỐI DB (MySQL XAMPP)
// ==============================
$host = 'localhost';
$db   = 'quanlydonhang_new1';
$user = 'root';   // mặc định XAMPP
$pass = '';       // mặc định rỗng

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=utf8",
        $user,
        $pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die("Lỗi kết nối DB: " . $e->getMessage());
}

// ==============================
// CẤU HÌNH GHN
// ==============================

// Token lấy trong mục Quản lý API của GHN
$GHN_TOKEN   = '2aad30fe-ced3-11f0-96e7-06587af5d159'; // giữ nguyên nếu đúng

// SHOP ID: chỉ là số "6113821", không kèm SĐT, phải để trong string hoặc số
$GHN_SHOP_ID = 6144095;   // hoặc '6113821';

// URL API GHN
$GHN_API_URL = 'https://online-gateway.ghn.vn/shiip/public-api';

// ==============================
// ĐỊA CHỈ GỬI (FROM) CỦA SHOP
// KHỚP VỚI GIAO DIỆN GHN:
// 242 Tô Hiệu, Hòa Minh, Liên Chiểu, Đà Nẵng
// ==============================
$GHN_FROM_NAME       = 'Hữu Kha';
$GHN_FROM_PHONE      = '0707722416';
$GHN_FROM_ADDRESS    = '242 Tô Hiệu';  // chỉ số nhà + tên đường
$GHN_FROM_DISTRICT   = 3441;           // Quận Liên Chiểu
$GHN_FROM_WARD       = '20503';        // Phường Hòa Minh
