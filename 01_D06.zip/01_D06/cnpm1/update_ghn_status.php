<?php
// update_ghn_status.php
require 'config.php';
require 'ghn_api.php';

/**
 * Map trạng thái GHN sang tiếng Việt cho DeliveryDetail.Status
 */
function mapDeliveryStatus($ghnStatus) {
    $ghnStatus = strtolower(trim($ghnStatus));

    switch ($ghnStatus) {
        case 'ready_to_pick':
        case 'picking':
        case 'storing':
        case 'transporting':
        case 'delivering':
            return 'Đang giao';

        case 'delivered':
            return 'Giao thành công';

        case 'delivery_fail':
            return 'Giao thất bại';

        case 'return':
        case 'returned':
            return 'Hoàn hàng';

        case 'cancel':
            return 'Đã hủy';

        default:
            return 'Không xác định (' . $ghnStatus . ')';
    }
}

/**
 * Map trạng thái GHN sang Orders.OrderStatus
 */
function mapOrderStatus($ghnStatus) {
    $ghnStatus = strtolower(trim($ghnStatus));

    switch ($ghnStatus) {
        case 'ready_to_pick':
        case 'picking':
        case 'storing':
        case 'transporting':
        case 'delivering':
            return 'Đang giao';

        case 'delivered':
            return 'Hoàn thành';

        case 'delivery_fail':
            return 'Thất bại';

        case 'return':
        case 'returned':
            return 'Hoàn hàng';

        case 'cancel':
            return 'Đã hủy';

        default:
            return 'Không xác định';
    }
}

/**
 * Cập nhật trạng thái thanh toán theo trạng thái GHN
 * Giả định: COD, chỉ "Đã thanh toán" khi delivered
 */
function updatePaymentStatusByGHN(PDO $pdo, $orderId, $ghnStatus) {
    $ghnStatus = strtolower(trim($ghnStatus));

    // Khi giao thành công -> Đã thanh toán
    if ($ghnStatus === 'delivered') {
        $stmt = $pdo->prepare("
            UPDATE Payment
            SET PaymentStatus = 'Đã thanh toán',
                PaymentDate   = NOW()
            WHERE OrderID = ?
        ");
        $stmt->execute([$orderId]);
        return "Payment: Đã thanh toán";
    }

    // Khi hủy / giao thất bại / hoàn hàng -> nếu chưa thanh toán thì đảm bảo là 'Chưa thanh toán'
    if (in_array($ghnStatus, ['cancel', 'delivery_fail', 'return', 'returned'])) {
        $stmt = $pdo->prepare("
            UPDATE Payment
            SET PaymentStatus = 'Chưa thanh toán',
                PaymentDate   = NULL
            WHERE OrderID = ?
              AND PaymentStatus <> 'Đã thanh toán'
        ");
        $stmt->execute([$orderId]);
        return "Payment: Chưa thanh toán";
    }

    // Các trạng thái khác: không động vào
    return "Payment: giữ nguyên";
}

// ===============================
// 1. Lấy danh sách đơn cần cập nhật
// ===============================

// Bỏ qua đơn DEMO & các trạng thái cuối cùng
$sql = "
    SELECT d.ID, d.OrderID, d.TrackingCode, d.Status AS CurrentStatus
    FROM DeliveryDetail d
    WHERE d.TrackingCode NOT LIKE 'GHN-DEMO-%'
      AND d.Status NOT IN ('Giao thành công','Giao thất bại','Hoàn hàng','Đã hủy')
";

$stmt = $pdo->query($sql);
$deliveries = $stmt->fetchAll(PDO::FETCH_ASSOC);

$results = [];

if (!$deliveries) {
    $results[] = "Không có đơn nào cần cập nhật.";
} else {
    foreach ($deliveries as $row) {
        $deliveryId   = $row['ID'];
        $orderId      = $row['OrderID'];
        $trackingCode = $row['TrackingCode'];

        try {
            // 2. Gọi GHN lấy chi tiết đơn
            $res = ghn_post('/v2/shipping-order/detail', [
                'order_code' => $trackingCode
            ]);

            if (empty($res['code']) || $res['code'] != 200 || empty($res['data'])) {
                $results[] = "❌ [$trackingCode] GHN trả lỗi/không có data: " . htmlspecialchars(json_encode($res));
                continue;
            }

            // data của GHN có thể là object hoặc mảng 1 phần tử
            $info = $res['data'];
            if (isset($info[0])) {
                $info = $info[0];
            }

            $ghnStatus = $info['status'] ?? '';
            if ($ghnStatus === '') {
                $results[] = "❌ [$trackingCode] Không tìm thấy 'status' trong data GHN.";
                continue;
            }

            $newDeliveryStatus = mapDeliveryStatus($ghnStatus);
            $newOrderStatus    = mapOrderStatus($ghnStatus);

            // 3. Cập nhật DB
            $pdo->beginTransaction();

            // Cập nhật DeliveryDetail
            $stmtUpdateD = $pdo->prepare("
                UPDATE DeliveryDetail
                SET Status = ?, UpdateDate = NOW()
                WHERE ID = ?
            ");
            $stmtUpdateD->execute([$newDeliveryStatus, $deliveryId]);

            // Cập nhật Orders
            $stmtUpdateO = $pdo->prepare("
                UPDATE Orders
                SET OrderStatus = ?
                WHERE ID = ?
            ");
            $stmtUpdateO->execute([$newOrderStatus, $orderId]);

            // Cập nhật PaymentStatus theo GHN
            $paymentNote = updatePaymentStatusByGHN($pdo, $orderId, $ghnStatus);

            $pdo->commit();

            $results[] = "✅ [$trackingCode] GHN status = <b>$ghnStatus</b> → "
                       . "Delivery = <b>$newDeliveryStatus</b>, "
                       . "Order = <b>$newOrderStatus</b>, "
                       . $paymentNote . ".";

        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $results[] = "❌ [$trackingCode] Exception: " . htmlspecialchars($e->getMessage());
        }
    }
}

// ===============================
// 4. Hiển thị kết quả
// ===============================
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Cập nhật trạng thái GHN & Thanh toán</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container py-4">
    <h3 class="mb-3">Cập nhật trạng thái giao hàng & thanh toán từ GHN</h3>
    <p class="text-muted">
        - Chỉ cập nhật các đơn có mã GHN thật (không phải GHN-DEMO).<br>
        - Khi GHN báo <code>delivered</code> → Payment chuyển sang <b>Đã thanh toán</b>.
    </p>

    <div class="card">
        <div class="card-body">
            <?php if ($results): ?>
                <ul class="list-group">
                    <?php foreach ($results as $line): ?>
                        <li class="list-group-item"><?= $line ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <div class="alert alert-info">Không có log.</div>
            <?php endif; ?>
        </div>
    </div>

    <div class="mt-3">
        <a href="index.php" class="btn btn-secondary">⬅ Về trang chủ</a>
    </div>
</div>
</body>
</html>
