<?php
// ghn_api.php
require 'config.php';

// Gửi request POST JSON tới GHN
function ghn_post($endpoint, $data) {
    global $GHN_API_URL, $GHN_TOKEN;

    $url = $GHN_API_URL . $endpoint;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => [
            "Content-Type: application/json",
            "Token: $GHN_TOKEN"
        ],
        CURLOPT_POSTFIELDS     => json_encode($data)
    ]);

    $response = curl_exec($ch);
    if ($response === false) {
        $err = curl_error($ch);
        curl_close($ch);
        throw new Exception("Lỗi cURL: $err");
    }
    curl_close($ch);

    $json = json_decode($response, true);
    return $json;
}
