<?php
require 'config.php';
require 'ghn_api.php';

require 'header.php';
?>

<h3 class="mb-3">Cập nhật trạng thái giao hàng từ GHN</h3>

<?php
$sql = "
SELECT ID, OrderID, TrackingCode, Status
FROM DeliveryDetail
WHERE TrackingCode IS NOT NULL
  AND Status NOT IN ('Giao thành công', 'Đã hủy')
";
$list = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

if (!$list): ?>
    <div class="alert alert-info">
        Không có đơn nào cần cập nhật. 
        <a href="orders_list.php" class="alert-link">Xem danh sách đơn</a>.
    </div>
<?php
else:
    echo '<div class="list-group">';
    foreach ($list as $row) {
        $deliveryId = $row['ID'];
        $orderId    = $row['OrderID'];
        $tracking   = $row['TrackingCode'];

        echo '<div class="list-group-item">';
        echo "<div><strong>Đơn $orderId</strong> - GHN: <code>$tracking</code></div>";

        try {
            $res = ghn_post('/v2/shipping-order/detail', [
                "order_code" => $tracking
            ]);

            if (!empty($res['code']) && $res['code'] == 200) {
                $ghnStatus = $res['data']['status'];

                // Cập nhật DB
                $stmt = $pdo->prepare("
                    UPDATE DeliveryDetail
                    SET Status = ?, UpdateDate = NOW()
                    WHERE ID = ?
                ");
                $stmt->execute([$ghnStatus, $deliveryId]);

                if ($ghnStatus === 'delivered' || $ghnStatus === 'Giao thành công') {
                    $stmt = $pdo->prepare("
                        UPDATE Orders
                        SET OrderStatus = 'Hoàn thành'
                        WHERE ID = ?
                    ");
                    $stmt->execute([$orderId]);

                    $stmt = $pdo->prepare("
                        UPDATE Payment
                        SET PaymentStatus = 'Đã thanh toán', PaymentDate = NOW()
                        WHERE OrderID = ?
                    ");
                    $stmt->execute([$orderId]);
                }

                echo '<div class="text-success small mt-1">✅ Cập nhật thành công → ' 
                     . htmlspecialchars($ghnStatus) . '</div>';
            } else {
                echo '<div class="text-danger small mt-1">❌ Lỗi GHN: ' 
                     . htmlspecialchars(json_encode($res)) . '</div>';
            }
        } catch (Exception $e) {
            echo '<div class="text-danger small mt-1">❌ Lỗi: ' 
                 . htmlspecialchars($e->getMessage()) . '</div>';
        }

        echo '</div>'; // list-group-item
    }
    echo '</div>'; // list-group
endif;
?>

<a href="orders_list.php" class="btn btn-outline-primary mt-3">📋 Quay lại danh sách đơn</a>

<?php
require 'footer.php';
