<?php
require 'config.php';

$sql = "
SELECT 
    o.ID AS OrderID,
    o.CustomerID,
    o.OrderDate,
    o.OrderStatus,
    d.TrackingCode,
    d.Status AS DeliveryStatus,
    p.PaymentMethod,
    p.PaymentStatus,
    p.PaymentDate
FROM Orders o
LEFT JOIN DeliveryDetail d ON o.ID = d.OrderID
LEFT JOIN Payment p ON o.ID = p.OrderID
ORDER BY o.OrderDate DESC
";

$rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

require 'header.php';
?>

<h3 class="mb-3">Danh sách đơn hàng</h3>

<?php if (!$rows): ?>
  <div class="alert alert-info">Chưa có đơn hàng nào.</div>
<?php else: ?>
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead class="table-primary">
        <tr>
          <th>Mã đơn</th>
          <th>Khách hàng</th>
          <th>Ngày đặt</th>
          <th>Trạng thái đơn</th>
          <th>Mã GHN</th>
          <th>Trạng thái giao hàng</th>
          <th>Thanh toán</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><span class="fw-semibold"><?= htmlspecialchars($r['OrderID']) ?></span></td>
          <td><?= htmlspecialchars($r['CustomerID']) ?></td>
          <td><?= $r['OrderDate'] ?></td>
          <td>
            <span class="badge bg-info text-dark"><?= htmlspecialchars($r['OrderStatus']) ?></span>
          </td>
          <td><?= htmlspecialchars($r['TrackingCode']) ?></td>
          <td>
            <?php if ($r['DeliveryStatus']): ?>
              <span class="badge bg-secondary"><?= htmlspecialchars($r['DeliveryStatus']) ?></span>
            <?php else: ?>
              <span class="text-muted">Chưa có</span>
            <?php endif; ?>
          </td>
          <td>
            <?php if ($r['PaymentStatus']): ?>
              <span class="badge 
                 <?= $r['PaymentStatus'] === 'Đã thanh toán' ? 'bg-success' : 'bg-warning text-dark' ?>">
                 <?= htmlspecialchars($r['PaymentMethod']) ?> - <?= htmlspecialchars($r['PaymentStatus']) ?>
              </span>
            <?php else: ?>
              <span class="text-muted">Chưa tạo</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<a href="create_order.php" class="btn btn-primary mt-2">➕ Tạo đơn mới</a>

<?php
require 'footer.php';
