<?php
require 'header.php';
?>

<div class="row justify-content-center">
  <div class="col-md-8">
    <div class="card shadow-sm border-0">
      <div class="card-body">
        <h3 class="card-title mb-3">Demo Shop tích hợp Giao Hàng Nhanh (GHN)</h3>
        <p class="text-muted">
          Đây là mô hình demo: tạo đơn hàng trên web, gọi API GHN để tạo vận đơn thực,
          lưu dữ liệu vào 3 bảng <code>Orders</code>, <code>DeliveryDetail</code>, <code>Payment</code>.
        </p>
        <hr>
        <div class="row text-center">
          <div class="col-md-4 mb-3">
            <a href="create_order.php" class="btn btn-primary w-100">
              🚚 Tạo đơn hàng mới
            </a>
          </div>
          <div class="col-md-4 mb-3">
            <a href="orders_list.php" class="btn btn-outline-primary w-100">
              📋 Danh sách đơn
            </a>
          </div>
          <div class="col-md-4 mb-3">
            <a href="update_delivery.php" class="btn btn-outline-secondary w-100">
              🔄 Cập nhật trạng thái GHN
            </a>
          </div>
        </div>
        <small class="text-muted">
          * Lưu ý: để đơn hiển thị trên GHN, bạn phải cấu hình đúng <code>Token</code> và <code>ShopID</code> trong <code>config.php</code>.
        </small>
      </div>
    </div>
  </div>
</div>

<?php
require 'footer.php';
