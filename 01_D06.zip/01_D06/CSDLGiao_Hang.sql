DROP TABLE IF EXISTS DeliveryDetail;
DROP TABLE IF EXISTS Payment;
DROP TABLE IF EXISTS Orders;

CREATE TABLE Orders (
    ID VARCHAR(10) PRIMARY KEY,
    CustomerID VARCHAR(10),
    OrderDate DATE,
    OrderStatus VARCHAR(50)
);

CREATE TABLE Payment (
    ID VARCHAR(10) PRIMARY KEY,
    OrderID VARCHAR(10),
    PaymentMethod VARCHAR(50),
    PaymentStatus VARCHAR(50),
    PaymentDate DATE,
    FOREIGN KEY (OrderID) REFERENCES Orders(ID)
);

CREATE TABLE DeliveryDetail (
    ID VARCHAR(10) PRIMARY KEY,
    OrderID VARCHAR(10),
    TrackingCode VARCHAR(50),
    UpdateDate DATE,
    Status VARCHAR(50),
    FOREIGN KEY (OrderID) REFERENCES Orders(ID)
);
